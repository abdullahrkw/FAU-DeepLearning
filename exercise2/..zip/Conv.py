import numpy as np
import scipy.signal

from Layers.Base import BaseLayer


class Conv(BaseLayer):
    def __init__(self, stride_shape, conv_shape, num_kernels):
        super().__init__()
        self.trainable = True

        self.num_kernels = num_kernels
        self.stride_shape = stride_shape
        self.conv_shape = conv_shape

        self.weights = np.random.uniform(0, 1, (num_kernels, *conv_shape))
        self.bias = np.random.rand(num_kernels) 

        self._padding = "same"
        self._optimizer = None
        self._gradient_weights = None
        self._gradient_bias = None

    def forward(self, inpT):
        batch_size = inpT.shape[0]
        self.inpT = inpT # storing for backprop
        batch_out = list()
        for item in range(batch_size):
            ker_conv = list()
            for ker in range(self.num_kernels):
                output = scipy.signal.correlate(inpT[item], self.weights[ker], self._padding)
                output = output[output.shape[0] // 2] + self.bias[ker]
                if (len(self.stride_shape) == 1):
                    output = output[::self.stride_shape[0]]
                elif (len(self.stride_shape) == 2):
                    output = output[::self.stride_shape[0], ::self.stride_shape[1]]
                ker_conv.append(output)
            batch_out.append(ker_conv)
            np_batch_out = np.array(batch_out)
        return np_batch_out

    @property
    def gradient_weights(self):
        return self._gradient_weights

    @property
    def gradient_bias(self):
        return self._gradient_bias

    @ property
    def optimizer(self):
        return self._optimizer

    @ optimizer.setter
    def optimizer(self, optimizer):
        self._optimizer = optimizer
